import { Connection } from 'mongoose';
export declare const videosProviders: {
    provide: string;
    useFactory: (connection: Connection) => import("mongoose").Model<import("mongoose").Document, {}>;
    inject: string[];
}[];
export declare class VideosModule {
}
