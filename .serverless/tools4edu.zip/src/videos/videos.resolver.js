"use strict";
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var __metadata = (this && this.__metadata) || function (k, v) {
    if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
};
var __param = (this && this.__param) || function (paramIndex, decorator) {
    return function (target, key) { decorator(target, key, paramIndex); }
};
Object.defineProperty(exports, "__esModule", { value: true });
const graphql_1 = require("@nestjs/graphql");
const videos_service_1 = require("./videos.service");
const video_model_1 = require("./models/video.model");
const stakeholders_service_1 = require("../stakeholders/stakeholders.service");
const stakeholder_model_1 = require("../stakeholders/models/stakeholder.model");
let VideosResolver = class VideosResolver {
    constructor(videosService, stakeholdersService) {
        this.videosService = videosService;
        this.stakeholdersService = stakeholdersService;
    }
    async video(id) {
        return this.videosService.findOne(id);
    }
    async videos() {
        return this.videosService.findAll();
    }
    async resolveStakeholder(video) {
        return this.stakeholdersService.findOne(video.stakeholder);
    }
};
__decorate([
    graphql_1.Query(returns => video_model_1.Video),
    __param(0, graphql_1.Args('id', { type: () => graphql_1.ID })),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", [String]),
    __metadata("design:returntype", Promise)
], VideosResolver.prototype, "video", null);
__decorate([
    graphql_1.Query(returns => [video_model_1.Video]),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", []),
    __metadata("design:returntype", Promise)
], VideosResolver.prototype, "videos", null);
__decorate([
    graphql_1.ResolveField('stakeholder', type => stakeholder_model_1.Stakeholder, {}),
    __param(0, graphql_1.Parent()),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", [video_model_1.Video]),
    __metadata("design:returntype", Promise)
], VideosResolver.prototype, "resolveStakeholder", null);
VideosResolver = __decorate([
    graphql_1.Resolver(of => video_model_1.Video),
    __metadata("design:paramtypes", [videos_service_1.VideosService,
        stakeholders_service_1.StakeholdersService])
], VideosResolver);
exports.VideosResolver = VideosResolver;
//# sourceMappingURL=videos.resolver.js.map