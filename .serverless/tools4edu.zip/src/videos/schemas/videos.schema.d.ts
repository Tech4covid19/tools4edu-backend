import * as mongoose from 'mongoose';
export declare const VideoSchema: mongoose.Schema<any>;
