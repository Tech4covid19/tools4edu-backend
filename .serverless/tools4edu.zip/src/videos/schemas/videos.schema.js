"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
const mongoose = require("mongoose");
exports.VideoSchema = new mongoose.Schema({
    order: {
        type: Number,
        required: true,
    },
    videoUrl: {
        type: String,
        required: true
    },
    title: {
        type: String,
        required: true
    },
    description: {
        type: String,
        required: true
    },
    stakeholder: {
        type: mongoose.Schema.Types.ObjectId, ref: 'Stakeholder'
    }
});
//# sourceMappingURL=videos.schema.js.map