export declare class Video {
    id: string;
    order: number;
    videoUrl: string;
    title: string;
    description: string;
    stakeholder: string;
}
