"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
class CreateVideoDto {
}
exports.CreateVideoDto = CreateVideoDto;
//# sourceMappingURL=create-video.dto.js.map