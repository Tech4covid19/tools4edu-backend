import { Stakeholder } from '../../stakeholders/interfaces/stakeholder.interface';
export declare class CreateVideoDto {
    readonly order: number;
    readonly videoUrl: string;
    readonly title: string;
    readonly description: string;
    readonly stakeholder: Stakeholder;
}
