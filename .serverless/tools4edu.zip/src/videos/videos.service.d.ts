import { Video } from './interfaces/video.interface';
import { Model } from 'mongoose';
import { CreateVideoDto } from './dto/create-video.dto';
import { StakeholdersService } from '../stakeholders/stakeholders.service';
export declare class VideosService {
    private videoModel;
    private stakeholdersService;
    constructor(videoModel: Model<Video>, stakeholdersService: StakeholdersService);
    create(createVideoDto: CreateVideoDto): Promise<Video>;
    findAll(query?: {}): Promise<Video[]>;
    findOne(id: string): Promise<Video>;
    delete(id: string): Promise<Video>;
    update(id: string, video: Video): Promise<Video>;
}
