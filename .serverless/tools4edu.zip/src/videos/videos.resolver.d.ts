import { VideosService } from './videos.service';
import { Video } from './models/video.model';
import { StakeholdersService } from '../stakeholders/stakeholders.service';
export declare class VideosResolver {
    private videosService;
    private stakeholdersService;
    constructor(videosService: VideosService, stakeholdersService: StakeholdersService);
    video(id: string): Promise<import("./interfaces/video.interface").Video>;
    videos(): Promise<import("./interfaces/video.interface").Video[]>;
    resolveStakeholder(video: Video): Promise<import("../stakeholders/interfaces/stakeholder.interface").Stakeholder>;
}
