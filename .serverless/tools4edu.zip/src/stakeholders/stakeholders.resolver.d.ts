import { StakeholdersService } from './stakeholders.service';
export declare class StakeholdersResolver {
    private stakeholdersService;
    constructor(stakeholdersService: StakeholdersService);
    stakeholder(id: string): Promise<import("./interfaces/stakeholder.interface").Stakeholder>;
}
