import { Model } from 'mongoose';
import { Stakeholder } from './interfaces/stakeholder.interface';
import { CreateStakeholderDto } from './dto/create-stakeholder.dto';
export declare class StakeholdersService {
    private stakeholderModel;
    constructor(stakeholderModel: Model<Stakeholder>);
    create(createStakeholderDto: CreateStakeholderDto): Promise<Stakeholder>;
    findAll(query?: {}): Promise<Stakeholder[]>;
    findOne(id: string): Promise<Stakeholder>;
    delete(id: string): Promise<Stakeholder>;
    update(id: string, stakeholder: Stakeholder): Promise<Stakeholder>;
}
