export declare class Stakeholder {
    id: string;
    code: string;
    title: string;
    description?: string;
}
