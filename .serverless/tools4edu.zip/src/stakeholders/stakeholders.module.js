"use strict";
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
Object.defineProperty(exports, "__esModule", { value: true });
const common_1 = require("@nestjs/common");
const stakeholders_service_1 = require("./stakeholders.service");
const stakeholders_resolver_1 = require("./stakeholders.resolver");
const stakeholders_schema_1 = require("./schemas/stakeholders.schema");
const constants_1 = require("../constants");
const database_module_1 = require("../database/database.module");
exports.stakeholdersProviders = [
    {
        provide: constants_1.STAKEHOLDER_MODEL,
        useFactory: (connection) => connection.model('Stakeholder', stakeholders_schema_1.StakeholderSchema),
        inject: [constants_1.DB_LANDINGPAGE_CONNECTION]
    }
];
let StakeholdersModule = class StakeholdersModule {
};
StakeholdersModule = __decorate([
    common_1.Module({
        imports: [database_module_1.DatabaseModule],
        providers: [
            ...exports.stakeholdersProviders,
            stakeholders_service_1.StakeholdersService,
            stakeholders_resolver_1.StakeholdersResolver
        ],
        exports: [
            ...exports.stakeholdersProviders,
            stakeholders_service_1.StakeholdersService,
            stakeholders_resolver_1.StakeholdersResolver
        ]
    })
], StakeholdersModule);
exports.StakeholdersModule = StakeholdersModule;
//# sourceMappingURL=stakeholders.module.js.map