import * as mongoose from 'mongoose';
export declare const StakeholderSchema: mongoose.Schema<any>;
