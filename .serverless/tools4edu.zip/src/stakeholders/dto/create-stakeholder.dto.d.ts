export declare class CreateStakeholderDto {
    readonly code: string;
    readonly title: string;
    readonly description: string;
}
