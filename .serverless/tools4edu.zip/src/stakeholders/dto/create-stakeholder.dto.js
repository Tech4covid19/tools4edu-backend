"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
class CreateStakeholderDto {
}
exports.CreateStakeholderDto = CreateStakeholderDto;
//# sourceMappingURL=create-stakeholder.dto.js.map