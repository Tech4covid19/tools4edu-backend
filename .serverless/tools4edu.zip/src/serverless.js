"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
const core_1 = require("@nestjs/core");
const platform_express_1 = require("@nestjs/platform-express");
const serverless = require("aws-serverless-express");
const express = require("express");
const app_module_1 = require("./app.module");
async function bootstrap() {
    const expressApp = express();
    const adapter = new platform_express_1.ExpressAdapter(expressApp);
    const app = await core_1.NestFactory.create(app_module_1.AppModule, adapter);
    await app.init();
    return serverless.createServer(expressApp);
}
exports.bootstrap = bootstrap;
let cachedServer;
exports.handler = (event, context) => {
    if (!cachedServer) {
        bootstrap().then(server => {
            cachedServer = server;
            return serverless.proxy(server, event, context);
        });
    }
    else {
        return serverless.proxy(cachedServer, event, context);
    }
};
//# sourceMappingURL=serverless.js.map