"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.DB_LANDINGPAGE_CONNECTION = 'DATABASE_LANDINGPAGE_CONNECTION';
exports.STAKEHOLDER_MODEL = 'STAKEHOLDER_MODEL_TOKEN';
exports.VIDEOS_MODEL = 'VIDEOS_MODEL_TOKEN';
exports.PROVIDERS_MODEL = 'PROVIDERS_MODEL_TOKEN';
//# sourceMappingURL=constants.js.map