import { Connection } from "mongoose";
export declare const providersProviders: {
    provide: string;
    useFactory: (connection: Connection) => import("mongoose").Model<import("mongoose").Document, {}>;
    inject: string[];
}[];
export declare class ProvidersModule {
}
