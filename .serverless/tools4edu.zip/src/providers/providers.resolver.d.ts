import { ProvidersService } from './providers.service';
import { Provider } from './models/provider.model';
export declare class ProvidersResolver {
    private providersService;
    constructor(providersService: ProvidersService);
    provider(code: string): Promise<import("./interfaces/provider.interface").Provider>;
    resolveVideos(provider: Provider): Promise<import("../videos/interfaces/video.interface").Video[]>;
}
