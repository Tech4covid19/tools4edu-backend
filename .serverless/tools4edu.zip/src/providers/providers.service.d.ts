import { Model } from "mongoose";
import { Provider } from './interfaces/provider.interface';
import { CreateProviderDto } from './dto/create-provider.dto';
import { Video } from '../videos/interfaces/video.interface';
export declare class ProvidersService {
    private providerModel;
    constructor(providerModel: Model<Provider>);
    create(createProviderDto: CreateProviderDto): Promise<Provider>;
    findAll(query?: {}): Promise<Provider[]>;
    getVideosForProvider(providerCode: string): Promise<Video[]>;
    findOneByCode(code: string): Promise<Provider>;
    delete(id: string): Promise<Provider>;
    update(id: string, provider: Provider): Promise<Provider>;
}
