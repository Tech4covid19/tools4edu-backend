export declare class Provider {
    id: string;
    order: number;
    code: string;
    title: string;
    description: string;
    videos: string[];
}
