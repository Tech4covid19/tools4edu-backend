"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
class CreateProviderDto {
}
exports.CreateProviderDto = CreateProviderDto;
//# sourceMappingURL=create-provider.dto.js.map