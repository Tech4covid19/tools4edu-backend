"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
//# sourceMappingURL=provider.interface.js.map