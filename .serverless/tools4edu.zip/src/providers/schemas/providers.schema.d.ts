import * as mongoose from 'mongoose';
export declare const ProviderSchema: mongoose.Schema<any>;
