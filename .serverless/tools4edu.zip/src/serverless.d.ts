import { Handler } from 'aws-lambda';
export declare function bootstrap(): Promise<any>;
export declare const handler: Handler;
